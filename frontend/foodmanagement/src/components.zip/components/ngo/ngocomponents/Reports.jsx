const Reports = () => (
    <div>
      <h2>Reports & Analytics</h2>
      <p>View statistics on donations, waste, and impact.</p>
    </div>
  );
  
  export default Reports;
  