const CommunityHub = () => (
    <div>
      <h2>Community Collaboration Hub</h2>
      <p>Connect with donors, volunteers, and NGOs.</p>
    </div>
  );
  
  export default CommunityHub;
  